abstract class AssetsImages
{

}